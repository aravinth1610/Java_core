package lamdaExpression;
// what to see the code .... 
interface MyFunc<T> {
	String func(T[] vals, T v2);
}

class HighTemp {
	private int hTemp;
	public HighTemp(int ht) {
		hTemp = ht;
	}
	
}

public class MethodReferenceToInstanceMethod {

}
