package Genrics;

public class WildCard {

}
